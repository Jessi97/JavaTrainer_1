package exception;

public class NoPreviousTrainerFoundException extends Exception{

	public String getMessage() {
		return "Es wurde kein vorheriger Trainer gefunden.";
	}
	
}