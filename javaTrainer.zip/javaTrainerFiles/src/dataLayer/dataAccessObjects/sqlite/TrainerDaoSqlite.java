package dataLayer.dataAccessObjects.sqlite;

/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;*/
import java.sql.*;
import java.util.List;

import businessObjects.ITrainer;

import dataLayer.businessObjects.Trainer;
import dataLayer.dataAccessObjects.ITrainerDao;
import exception.NoNextTrainerFoundException;
import exception.NoPreviousTrainerFoundException;
import exception.NoTrainerFoundException;


public class TrainerDaoSqlite implements ITrainerDao{

	
	private Connection connection = null;  
	private final String DB_PATH = System.getProperty("user.home") + "/" + "javaTrainer.db"; 
	  
    private Statement statement = null; 
    private ResultSet rs;

        public TrainerDaoSqlite()
        {
        	try {
    	        Class.forName("org.sqlite.JDBC");
    	        /* Achtung!!!!!!!
    	         Link von Databse eingeben
    	        */ 
    	        connection = DriverManager.getConnection("jdbc:sqlite:"+DB_PATH);
    	        this.init(connection);
    	      } catch ( Exception e ) {
    	        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
    	        System.exit(0);
    	      }
    	      System.out.println("Opened database successfully");
        }
	
	public void init(Connection connection) {
		try {
			statement = connection.createStatement();
			statement.executeUpdate("CREATE TABLE IF NOT EXISTS Trainer (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME VARCHAR(50), VORNAME VARCHAR(50), AGE INT, ERFAHRUNG INT)");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public ITrainer createTrainer() {
		ITrainer trainer = new Trainer(9999, "", "", 0, 0);
		
		return trainer;
	}

	@Override
	public void delete(ITrainer iTrainer) {
		
		String query = "DELETE FROM Trainer where `id` =" + iTrainer.getId();
		try {
			statement = connection.createStatement();
			statement.execute( query );
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}		

	@Override
	public ITrainer selectFirst() {
		ITrainer trainer = null ;
		try {
			//rs = statement.executeQuery( "Select * FROM Trainer order by `id` fetch first 1 rows only ");
			
			statement = connection.createStatement();
			
			
			rs = statement.executeQuery( "Select * FROM Trainer order by `id` LIMIT 1");
			
			String vname = (String) rs.getObject(2),
					   nname = (String) rs.getObject(3);
				Integer alter = (Integer) rs.getObject(4),
					   erfahrung = (Integer) rs.getObject(5),
					   this_id = (Integer) rs.getObject(1);
			
			
			
			trainer = new Trainer(this_id, nname, vname, alter, erfahrung);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return trainer;
	}

	@Override
	public ITrainer selectLast() {
		ITrainer trainer = null ;
		try {
			statement = connection.createStatement();
			
			
			rs = statement.executeQuery( "Select * FROM Trainer order by `id` DESC LIMIT 1");
			
			String vname = (String) rs.getObject(2),
					   nname = (String) rs.getObject(3);
				Integer alter = (Integer) rs.getObject(4),
					   erfahrung = (Integer) rs.getObject(5),
					   this_id = (Integer) rs.getObject(1);
			
			
			
			trainer = new Trainer(this_id, nname, vname, alter, erfahrung);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return trainer;
	}

	@Override
	public ITrainer selectNext(ITrainer iTrainer) throws NoNextTrainerFoundException, SQLException {
		ITrainer trainer = null ;
		try {
			
			statement = connection.createStatement();
			
			rs = statement.executeQuery( "Select * FROM Trainer WHERE `id` > " + iTrainer.getId() + " order by `id` LIMIT 1");
			
			String vname = (String) rs.getObject(2),
					   nname = (String) rs.getObject(3);
				Integer alter = (Integer) rs.getObject(4),
					   erfahrung = (Integer) rs.getObject(5),
					   this_id = (Integer) rs.getObject(1);
			
			
			
			trainer = new Trainer(this_id, nname, vname, alter, erfahrung);
			
		} catch (SQLException e) {
			throw new NoNextTrainerFoundException();
		} catch (NullPointerException ex) {
			throw new NoNextTrainerFoundException();
		}
		return trainer;
	}

	@Override
	public ITrainer selectPrevious(ITrainer iTrainer) throws NoPreviousTrainerFoundException, SQLException  {
		ITrainer trainer = null ;
		try {
			statement = connection.createStatement();
			
			rs = statement.executeQuery( "Select * FROM Trainer WHERE `id` < " + iTrainer.getId() + " order by `id` DESC LIMIT 1");
			
			String vname = (String) rs.getObject(2),
					   nname = (String) rs.getObject(3);
				Integer alter = (Integer) rs.getObject(4),
					   erfahrung = (Integer) rs.getObject(5),
					   this_id = (Integer) rs.getObject(1);
			
			
			
			trainer = new Trainer(this_id, nname, vname, alter, erfahrung);
		} catch (SQLException e) {
			throw new NoPreviousTrainerFoundException();
		}
		return trainer;
	}
	
	@Override
	public void save(ITrainer iTrainer) {
		
		if (!iTrainer.getVName().equals(""))
		{
			// query existiert id
			
			
			
			try {
				statement = connection.createStatement();
				
				
				
				String query = "insert into Trainer (`id`, `NAME`, `VORNAME`, `AGE`, `ERFAHRUNG`) values(NULL, '"+iTrainer.getNName()+"', '" +iTrainer.getVName()+"', "+iTrainer.getAlter()+","+iTrainer.getErfahrung()+") ";
				
				statement.execute( query );
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public List<ITrainer> selectTrainer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ITrainer selectTrainerById(int id) throws NoTrainerFoundException {
		ITrainer trainer = null ;
		try {
			
			
			rs = statement.executeQuery( "Select * FROM Trainer where `id` = " + id);
			
			String vname = (String) rs.getObject(2),
				   nname = (String) rs.getObject(3);
			Integer alter = (Integer) rs.getObject(4),
				   erfahrung = (Integer) rs.getObject(5),
				   this_id = (Integer) rs.getObject(1);
			
			trainer = new Trainer(this_id, nname, vname, alter, erfahrung);
		} catch (SQLException e) {
			throw new NoTrainerFoundException();
			
		}
		return trainer;
	}
	
	@Override
	public void update(ITrainer iTrainer) {
		
		String query = "UPDATE Trainer SET VORNAME = '" + iTrainer.getVName() +
				"', NAME = '" + iTrainer.getNName() +
				"', AGE = '" + iTrainer.getAlter() +
				"', ERFAHRUNG = '" + iTrainer.getErfahrung() +
				 "' WHERE `id` LIKE '" + iTrainer.getId() + "'";
		
		try {
			statement = connection.createStatement();
			statement.execute( query );
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*
		if (iTrainer.getNName() != ""){
			try {
				rs = statement.executeQuery("update Trainer set name = " +iTrainer.getNName()+ " where `id` = " +iTrainer.getId());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (iTrainer.getVName() != ""){
			try {
				rs = statement.executeQuery("update Trainer set vorname = " +iTrainer.getVName()+ " where `id` = " +iTrainer.getId());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (iTrainer.getErfahrung() != 0){
			try {
				rs = statement.executeQuery("update Trainer set erfahrung = " +iTrainer.getErfahrung()+ " where `id` = " +iTrainer.getId());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (iTrainer.getAlter() != 0){
			try {
				rs = statement.executeQuery("update Trainer set alter = " +iTrainer.getAlter()+ " where `id` = " +iTrainer.getId());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		*/
	} 

}
