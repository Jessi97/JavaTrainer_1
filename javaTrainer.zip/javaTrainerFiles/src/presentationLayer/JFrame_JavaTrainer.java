package presentationLayer;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javaTrainer.NumericHelper;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import settings.PersistenceSettings;
import settings.SettingsManager;

import businessObjects.ITrainer;


import dataLayer.businessObjects.Trainer;
import dataLayer.dataAccessObjects.ITrainerDao;
import dataLayer.dataAccessObjects.sqlite.TrainerDaoSqlite;
import dataLayer.dataAccessObjects.xml.TrainerDaoXml;
import exception.NoNextTrainerFoundException;
import exception.NoPreviousTrainerFoundException;
import exception.NoTrainerFoundException;

public class JFrame_JavaTrainer extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7550695899663744809L;
	private JPanel contentPane;
	private JTextField textField_ID;
	private JTextField textField_NName;
	private JTextField textField_VName;
	private JTextField textField_Alter;
	private JTextField textField_Erfahrung;
	private int ID;
	private Trainer trainer;
	public ITrainerDao trainerdao;
	private JButton btn_Delete;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					JFrame_JavaTrainer frame = new JFrame_JavaTrainer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		});
	}

	private void initDao() {
		SettingsManager settingsManager = SettingsManager.getInstance();
		PersistenceSettings persSettings = settingsManager.getPersistenceSettings();
		String readingType = persSettings.getPersistanceType();
		if(readingType.contains("sqlite")) {
			trainerdao = new TrainerDaoSqlite();
		} else {
			trainerdao = new TrainerDaoXml();
		}
	}
	/**
	 * Create the frame.
	 */
	public JFrame_JavaTrainer() {
		initDao();
		setTitle("Verwaltung - Trainerdaten");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 438, 318);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		textField_ID = new JTextField();
		textField_ID.setBounds(12, 13, 264, 22);
		panel.add(textField_ID);
		textField_ID.setColumns(10);
		
		JButton button_Suchen = new JButton("Suchen");
		button_Suchen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					buttonSuchenActionPerformed(e);
				} catch (NoTrainerFoundException | SQLException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),"Fehlermeldung",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		button_Suchen.setBounds(288, 12, 110, 25);
		panel.add(button_Suchen);
		
		textField_NName = new JTextField();
		textField_NName.setBounds(129, 44, 269, 22);
		panel.add(textField_NName);
		textField_NName.setColumns(10);
		
		JLabel lblName = new JLabel("Nachname:");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblName.setBounds(12, 47, 97, 16);
		panel.add(lblName);
		
		JLabel lblNewLabel = new JLabel("Alter:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(12, 110, 56, 16);
		panel.add(lblNewLabel);
		
		JLabel lblVorname = new JLabel("Vorname:");
		lblVorname.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblVorname.setBounds(12, 81, 77, 16);
		panel.add(lblVorname);
		
		textField_VName = new JTextField();
		textField_VName.setBounds(129, 75, 269, 22);
		panel.add(textField_VName);
		textField_VName.setColumns(10);
		
		textField_Alter = new JTextField();
		textField_Alter.setBounds(129, 108, 269, 22);
		panel.add(textField_Alter);
		textField_Alter.setColumns(10);
		
		JLabel lblErfahrung = new JLabel("Erfahrung:");
		lblErfahrung.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblErfahrung.setBounds(12, 142, 97, 22);
		panel.add(lblErfahrung);
		
		textField_Erfahrung = new JTextField();
		textField_Erfahrung.setBounds(129, 143, 269, 22);
		panel.add(textField_Erfahrung);
		textField_Erfahrung.setColumns(10);
		
		JButton button_First = new JButton("<<");
		button_First.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_First.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					buttonFirstActionPerformed(e);
				} catch (NoTrainerFoundException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),"Fehlermeldung",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		button_First.setBounds(73, 219, 49, 25);
		panel.add(button_First);
		
		JButton button_Last = new JButton(">>");
		button_Last.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_Last.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					buttonLastActionPerformed(e);
				} catch (NoTrainerFoundException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),"Fehlermeldung",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		button_Last.setBounds(250, 219, 49, 25);
		panel.add(button_Last);
		
		JButton button_Next = new JButton("<");
		button_Next.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_Next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					buttonPreviousActionPerformed(e);
				} catch (NoPreviousTrainerFoundException | SQLException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),"Fehlermeldung",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		button_Next.setBounds(132, 219, 49, 25);
		panel.add(button_Next);
		
		JButton button_Previous = new JButton(">");
		button_Previous.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_Previous.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					buttonNextActionPerformed(e);
				} catch (NoNextTrainerFoundException | SQLException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),"Fehlermeldung",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		button_Previous.setBounds(191, 219, 49, 25);
		panel.add(button_Previous);
		
		JButton button_Exit = new JButton("Beenden");
		button_Exit.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_Exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonBeendenActionPerformed(e); 
			}
		});
		button_Exit.setBounds(321, 234, 77, 25);
		panel.add(button_Exit);
		
		JButton button_Aendern = new JButton("\u00C4ndern");
		button_Aendern.setFont(new Font("Tahoma", Font.PLAIN, 9));
		button_Aendern.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonAendernActionPerformed(e);
			}
		});
		
		button_Aendern.setBounds(99, 191, 89, 25);
		panel.add(button_Aendern);
		
		JButton btnNewButton_1 = new JButton("Leeren");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				buttonNeuActionPerformed(arg0);
			}
		});
		btnNewButton_1.setBounds(12, 191, 77, 25);
		panel.add(btnNewButton_1);
		
		JButton btnSpeichern = new JButton("Speichern");
		btnSpeichern.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnSpeichern.setBounds(198, 191, 101, 25);
		btnSpeichern.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ITrainer newTrainer = trainerdao.createTrainer();
				
				newTrainer.setNName(textField_NName.getText());
				
				newTrainer.setVName(textField_VName.getText());
				
				if(NumericHelper.isNumeric(textField_Alter.getText())){
					newTrainer.setAlter(Integer.parseInt(textField_Alter.getText()));				
				}
				
				if(NumericHelper.isNumeric(textField_Erfahrung.getText())){
					newTrainer.setErfahrung(Integer.parseInt(textField_Erfahrung.getText()));				
				}
				
				trainerdao.save(newTrainer);
			}
		});
		panel.add(btnSpeichern);
		{
			btn_Delete = new JButton("L\u00F6schen");
			btn_Delete.setFont(new Font("Tahoma", Font.PLAIN, 9));
			btn_Delete.setBounds(309, 192, 89, 23);
			btn_Delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					buttonDeleteActionPerformed(e);
				} catch (NoTrainerFoundException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),"Fehlermeldung",JOptionPane.ERROR_MESSAGE);
				}
			}
		});	
	} panel.add(btn_Delete);
}
	

		protected void buttonNeuActionPerformed(ActionEvent arg0) {
			textField_ID.setText(null);
			textField_NName.setText(null);
			textField_VName.setText(null);
			textField_Alter.setText(null);
			textField_Alter.setText(null);
			textField_Erfahrung.setText(null);
}
		protected void buttonAendernActionPerformed(ActionEvent e){
			trainer.setNName(textField_NName.getText());
			trainer.setVName(textField_VName.getText());
			if(NumericHelper.isNumeric(textField_Alter.getText())){
				trainer.setAlter(Integer.parseInt(textField_Alter.getText()));				
			}
			
			if(NumericHelper.isNumeric(textField_Erfahrung.getText())){
				trainer.setErfahrung(Integer.parseInt(textField_Erfahrung.getText()));				
			}
			trainerdao.update(trainer);
}			
			
		protected void buttonBeendenActionPerformed(ActionEvent e) {
			System.exit(0);
  }
		protected void buttonFirstActionPerformed(ActionEvent e) throws NoTrainerFoundException{
			trainer = (Trainer) trainerdao.selectFirst();
			textField_ID.setText(Integer.toString(trainer.getId()));
			textField_NName.setText(trainer.getNName());
			textField_VName.setText(trainer.getVName());
			textField_Alter.setText(Integer.toString(trainer.getAlter()));
			textField_Erfahrung.setText(Integer.toString(trainer.getErfahrung()));
  }
		protected void buttonPreviousActionPerformed(ActionEvent e) throws NoPreviousTrainerFoundException, SQLException{
			trainer = (Trainer) trainerdao.selectPrevious(trainer);
			textField_ID.setText(Integer.toString(trainer.getId()));
			textField_NName.setText(trainer.getNName());
			textField_VName.setText(trainer.getVName());
			textField_Alter.setText(Integer.toString(trainer.getAlter()));
			textField_Erfahrung.setText(Integer.toString(trainer.getErfahrung()));
  }
		protected void buttonNextActionPerformed(ActionEvent e) throws NoNextTrainerFoundException, SQLException{
			trainer = (Trainer) trainerdao.selectNext(trainer);
			textField_ID.setText(Integer.toString(trainer.getId()));
			textField_NName.setText(trainer.getNName());
			textField_VName.setText(trainer.getVName());
			textField_Alter.setText(Integer.toString(trainer.getAlter()));
			textField_Erfahrung.setText(Integer.toString(trainer.getErfahrung()));
  }
		protected void buttonLastActionPerformed(ActionEvent e) throws NoTrainerFoundException{
			trainer = (Trainer) trainerdao.selectLast();
			textField_ID.setText(Integer.toString(trainer.getId()));
			textField_NName.setText(trainer.getNName());
			textField_VName.setText(trainer.getVName());
			textField_Alter.setText(Integer.toString(trainer.getAlter()));
			textField_Erfahrung.setText(Integer.toString(trainer.getErfahrung()));
		}
		
		protected void buttonSuchenActionPerformed(ActionEvent e) throws NoTrainerFoundException, SQLException{
			ID = Integer.parseInt(textField_ID.getText());
			trainer = (Trainer) trainerdao.selectTrainerById(ID);
			textField_ID.setText(Integer.toString(trainer.getId()));
			textField_NName.setText(trainer.getNName());
			textField_VName.setText(trainer.getVName());
			textField_Alter.setText(Integer.toString(trainer.getAlter()));
			textField_Erfahrung.setText(Integer.toString(trainer.getErfahrung()));
	}
		protected void buttonDeleteActionPerformed(ActionEvent e) throws NoTrainerFoundException {
			System.out.println("Hallo");
			trainerdao.delete(trainer);
		}
}
