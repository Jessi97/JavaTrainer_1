package settings;

public class PersistenceSettings {

private String persistanceType;


public String getPersistanceType(){
	return persistanceType;
}

public void setPersistanceType(String persistanceType){
	this.persistanceType = persistanceType; 
}


}

