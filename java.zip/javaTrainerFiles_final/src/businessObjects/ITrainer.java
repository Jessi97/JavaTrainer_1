package businessObjects;

public interface ITrainer{
	
	public int getId();
	public String getNName();
	public void setNName(String nname);
	public String getVName();
	public void setVName(String vname);
	public int getAlter();
	public void setAlter(int alter);
	public int getErfahrung();
	public void setErfahrung(int erfahrung);
		
}
