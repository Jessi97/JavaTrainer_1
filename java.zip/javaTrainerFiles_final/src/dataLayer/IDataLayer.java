package dataLayer;

import dataLayer.dataAccessObjects.ITrainerDao;

public interface IDataLayer
{
    public ITrainerDao getTrainerDao();
}