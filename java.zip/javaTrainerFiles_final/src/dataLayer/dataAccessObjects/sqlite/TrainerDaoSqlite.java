package dataLayer.dataAccessObjects.sqlite;

/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;*/
import java.sql.*;
import java.util.List;

import businessObjects.ITrainer;

import dataLayer.dataAccessObjects.ITrainerDao;
import exception.NoNextTrainerFoundException;
import exception.NoPreviousTrainerFoundException;


public class TrainerDaoSqlite implements ITrainerDao{

	
	private Connection connection = null;  
	private final String DB_PATH = System.getProperty("user.home") + "/" + "javaTrainer.db"; 
	  
    private Statement statement = null; 
    private ResultSet rs;

        public TrainerDaoSqlite()
        {
        	try {
    	        Class.forName("org.sqlite.JDBC");
    	        /* Achtung!!!!!!!
    	         Link von Databse eingeben
    	        */ 
    	        connection = DriverManager.getConnection("jdbc:sqlite:"+DB_PATH);
    	        this.init(connection);
    	      } catch ( Exception e ) {
    	        System.err.println( e.getClass().getName() + ": " + e.getMessage() );
    	        System.exit(0);
    	      }
    	      System.out.println("Opened database successfully");
        }
	
	public void init(Connection connection) {
		try {
			statement = connection.createStatement();
			statement.executeUpdate("CREATE TABLE IF NOT EXISTS Trainer (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME VARCHAR(50), VORNAME VARCHAR(50), AGE INT, ERFAHRUNG INT)");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public ITrainer createTrainer() {
		ITrainer trainer = null ;
		try {
			rs = statement.executeQuery( "insert into Trainer values(" +trainer.getId()+","+trainer.getNName()+"," +trainer.getVName()+","+trainer.getAlter()+","+trainer.getErfahrung()+") " );
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return trainer;
	}

	@Override
	public void delete(ITrainer iTrainer) {
		
		try {
			rs = statement.executeQuery( "DELETE FROM Trainer where trainerID =" + iTrainer.getId() );
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public ITrainer selectFirst() {
		ITrainer trainer = null ;
		try {
			rs = statement.executeQuery( "Select * FROM Trainer order by trainerID fetch first 1 rows only ");
			trainer = (ITrainer) rs.getObject(0);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return trainer;
	}

	@Override
	public ITrainer selectLast() {
		ITrainer trainer = null ;
		try {
			rs = statement.executeQuery( "Select * FROM Trainer order by trainerID desc fetch first 1 rows only ");
			trainer = (ITrainer) rs.getObject(0);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return trainer;
	}

	@Override
	public ITrainer selectNext(ITrainer iTrainer) throws NoNextTrainerFoundException, SQLException {
		ITrainer trainer = null ;
		try {
			rs = statement.executeQuery( "Select * FROM Trainer where trainerID > " +trainer.getId()+ "order by trainerID fetch first 1 rows only ");
			trainer = (ITrainer) rs.getObject(0);
		} catch (SQLException e) {
			throw new NoNextTrainerFoundException();
		} catch (NullPointerException ex) {
			throw new NoNextTrainerFoundException();
		}
		return trainer;
	}

	@Override
	public ITrainer selectPrevious(ITrainer iTrainer) throws NoPreviousTrainerFoundException, SQLException  {
		ITrainer trainer = null ;
		try {
			rs = statement.executeQuery( "Select * FROM Trainer where trainerID < " +trainer.getId()+ "order by trainerID desc fetch first 1 rows only ");
			trainer = (ITrainer) rs.getObject(0);
		} catch (SQLException e) {
			throw new NoPreviousTrainerFoundException();
		}
		return trainer;
	}

	/*
	public void save(List<ITrainer> trainers) {
		
		for(trainer : trainers)
			
			save(trainer);
	}
	*/
	
	@Override
	public void save(ITrainer iTrainer) {
		if (iTrainer.getId() != 0){
			createTrainer();
		}
		
	}

	@Override
	public List<ITrainer> selectTrainer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ITrainer selectTrainerById(int id) {
		ITrainer trainer = null ;
		try {
			rs = statement.executeQuery( "Select * FROM Trainer where trainerID = " + id);
			trainer = (ITrainer) rs.getObject(0);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return trainer;
	}
	
	@Override
	public void update(ITrainer iTrainer) {
		
		if (iTrainer.getNName() != ""){
			try {
				rs = statement.executeQuery("update Trainer set name = " +iTrainer.getNName()+ " where trainerID = " +iTrainer.getId());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (iTrainer.getVName() != ""){
			try {
				rs = statement.executeQuery("update Trainer set vorname = " +iTrainer.getVName()+ " where trainerID = " +iTrainer.getId());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (iTrainer.getErfahrung() != 0){
			try {
				rs = statement.executeQuery("update Trainer set erfahrung = " +iTrainer.getErfahrung()+ " where trainerID = " +iTrainer.getId());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (iTrainer.getAlter() != 0){
			try {
				rs = statement.executeQuery("update Trainer set alter = " +iTrainer.getAlter()+ " where trainerID = " +iTrainer.getId());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	} 

}
