package dataLayer.dataAccessObjects;

import java.sql.SQLException;
import java.util.List;

import exception.NoNextTrainerFoundException;
import exception.NoPreviousTrainerFoundException;

import businessObjects.ITrainer;


/**
 * Created by Marvin on 9/2/2016.
 */
public interface ITrainerDao
{
    public ITrainer createTrainer();

    public void delete(ITrainer iTrainer);

    public ITrainer selectFirst();

    public ITrainer selectLast();

    public ITrainer selectNext(ITrainer iTrainer) throws NoNextTrainerFoundException, SQLException;

    public ITrainer selectPrevious(ITrainer iTrainer) throws NoPreviousTrainerFoundException, SQLException;

    public void save (ITrainer iTrainer);

    public List<ITrainer> selectTrainer();

    public ITrainer selectTrainerById(int id);

	public void update(ITrainer iTrainer);
}
