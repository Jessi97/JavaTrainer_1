package exception;

public class NoTrainerFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String ERROR_MESSAGE = "Es wurde kein Trainer gefunden.";
	public String getMessage() {
		return ERROR_MESSAGE;
	}
	public String toString() {
		return ERROR_MESSAGE;
	}

}
