package exception;

public class NoNextTrainerFoundException extends Exception{

	
		public String getMessage() {
			return "Es wurde kein n�chster Trainer gefunden.";
		
	}
}
